import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

Deno.serve(async (req) => {
  try {
      const url = new URL(req.url);

          // Link do tipo: /functions/v1/r?id=123&token=abc
              const idStr = url.searchParams.get("id");
                  const token = url.searchParams.get("token") ?? "";

                      if (!idStr) return new Response("missing id", { status: 400 });

                          const id = Number(idStr);
                              if (!Number.isFinite(id) || id <= 0) return new Response("invalid id", { status: 400 });

                                  const supabaseUrl = Deno.env.get("SUPABASE_URL");
                                      const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

                                          if (!supabaseUrl || !serviceKey) {
                                                return new Response("missing env vars", { status: 500 });
                                                    }

                                                        const supabase = createClient(supabaseUrl, serviceKey);

                                                            // ✅ chama sua função do Postgres: resolve_link(bigint, text)
                                                                const { data, error } = await supabase.rpc("resolve_link", {
                                                                      p_id: id,
                                                                            p_token: token,
                                                                                });

                                                                                    if (error || !data) return new Response("not found", { status: 404 });

                                                                                        // 302 redirect pro destino
                                                                                            return new Response(null, {
                                                                                                  status: 302,
                                                                                                        headers: {
                                                                                                                Location: String(data),
                                                                                                                        "Cache-Control": "no-store",
                                                                                                                              },
                                                                                                                                  });
                                                                                                                                    } catch (e) {
                                                                                                                                        console.error(e);
                                                                                                                                            return new Response("server error", { status: 500 });
                                                                                                                                              }
                                                                                                                                              });